document.addEventListener("DOMContentLoaded", function () {
    document.addEventListener("click", function (event) {
        if (event.target.matches(".delete-comment")) {
            event.preventDefault();

            const commentId = event.target.getAttribute("data-comment-id");

            // 確認是否刪除
            const confirmDelete = confirm("確定要刪除此留言嗎？");
            if (!confirmDelete) return;

            // 發送刪除請求
            fetch("../pages/delete_comment.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ id: commentId }),
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        // 從 DOM 中移除留言
                        const commentElement = document.getElementById(`comment-${commentId}`);
                        if (commentElement) {
                            commentElement.remove();
                        }
                        alert("留言已刪除！");
                    } else {
                        alert(`刪除失敗：${data.error}`);
                    }
                })
                .catch((error) => {
                    console.error("刪除失敗：", error);
                    alert("刪除時發生錯誤，請稍後再試！");
                });
        }
    });
});
