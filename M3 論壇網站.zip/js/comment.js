document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".edit-comment").forEach(function (button) {
        button.addEventListener("click", function (e) {
            e.preventDefault(); // 防止默認行為
            const commentId = this.dataset.commentId;
            const contentElement = document.getElementById("content-" + commentId);

            // 保存原始內容以便取消時恢復
            const originalContent = contentElement.innerText;

            // 創建 textarea 作為編輯框
            const textarea = document.createElement("textarea");
            textarea.value = originalContent;
            textarea.style.width = "100%";
            textarea.rows = 3;
            textarea.classList.add("editing");

            // 替換留言內容為 textarea
            contentElement.replaceWith(textarea);
            textarea.focus(); // 聚焦於文本框

            // 鍵盤事件處理
            textarea.addEventListener("keydown", function (event) {
                if (event.key === "Escape") {
                    // 按下 ESC 鍵取消編輯
                    cancelEdit();
                } else if (event.key === "Enter") {
                    // 按下 Enter 鍵保存編輯
                    event.preventDefault(); // 防止換行
                    saveEdit();
                }
            });

            // 保存功能
            function saveEdit() {
                const newContent = textarea.value;

                // 發送 AJAX 請求
                fetch("edit_comment.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ id: commentId, content: newContent }),
                })
                    .then((response) => response.json())
                    .then((data) => {
                        if (data.success) {
                            // 更新顯示內容
                            const updatedContent = document.createElement("p");
                            updatedContent.id = "content-" + commentId;
                            updatedContent.innerText = newContent;
                            textarea.replaceWith(updatedContent);
                        } else {
                            alert("保存失敗：" + data.error);
                        }
                    })
                    .catch((error) => {
                        console.error("發生錯誤：", error);
                    });
            }

            // 取消功能
            function cancelEdit() {
                const restoredContent = document.createElement("p");
                restoredContent.id = "content-" + commentId;
                restoredContent.innerText = originalContent;
                textarea.replaceWith(restoredContent);
            }
        });
    });
});
