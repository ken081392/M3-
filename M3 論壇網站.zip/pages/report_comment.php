<?php
session_start();
include '../includes/db_connection.php';
$conn = OpenCon();

// 确认请求是否为 POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["success" => false, "message" => "无效的请求方式"]);
    exit();
}

// 验证是否已登录
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["success" => false, "message" => "请先登录后才能通报"]);
    exit();
}

// 验证通报数据
$comment_id = intval($_POST['comment_id'] ?? 0);
$reason = trim($_POST['reason'] ?? "");

if ($comment_id <= 0 || empty($reason)) {
    echo json_encode(["success" => false, "message" => "通报数据不完整"]);
    exit();
}

// 插入通报数据到 reports_comment 表
$insert_query = "INSERT INTO reports_comment (comment_id, user_id, reason, reported_at) VALUES (?, ?, ?, NOW())";
$stmt = $conn->prepare($insert_query);

if (!$stmt) {
    error_log("SQL 准备失败：" . $conn->error);
    echo json_encode(["success" => false, "message" => "系统错误，请稍后再试"]);
    exit();
}

$stmt->bind_param("iis", $comment_id, $_SESSION['user_id'], $reason);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "留言通报成功"]);
} else {
    error_log("SQL 执行失败：" . $stmt->error);
    echo json_encode(["success" => false, "message" => "通报失败，请稍后再试"]);
}

$stmt->close();
exit();
?>
