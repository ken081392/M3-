<?php
session_start();
include '../includes/db_connection.php';

$conn = OpenCon();

// 確認用戶是否登入
if (!isset($_SESSION['user_id'])) {
    die("請先登入後再執行通報操作。");
}

// 驗證留言 ID
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $comment_id = intval($_GET['id']);
} else {
    die("無效的留言 ID。");
}

// 檢查是否已通報過
$check_query = "SELECT * FROM reports_comment WHERE comment_id = ? AND user_id = ?";
$check_stmt = $conn->prepare($check_query);

if (!$check_stmt) {
    die("SQL 錯誤：" . $conn->error); // 顯示具體的 SQL 錯誤
}

$check_stmt->bind_param("ii", $comment_id, $_SESSION['user_id']);
$check_stmt->execute();
$result = $check_stmt->get_result();

if ($result->num_rows > 0) {
    echo "您已經通報過此留言！";
    exit();
}

// 插入新的通報記錄
$report_query = "INSERT INTO reports_comment (comment_id, user_id, reported_at) VALUES (?, ?, NOW())";
$report_stmt = $conn->prepare($report_query);

if (!$report_stmt) {
    die("SQL 錯誤：" . $conn->error); // 顯示具體的 SQL 錯誤
}

$report_stmt->bind_param("ii", $comment_id, $_SESSION['user_id']);

if ($report_stmt->execute()) {
    echo "留言已成功通報！";
    header("Location: post_detail.php?id=" . intval($_GET['post_id']));
    exit();
} else {
    die("通報失敗：" . $conn->error);
}
?>
