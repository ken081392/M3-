<?php
session_start();
include '../includes/db_connection.php';

$conn = OpenCon();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 解析 JSON 請求
    $data = json_decode(file_get_contents('php://input'), true);

    // 確認收到的資料是否完整
    if (isset($data['id'], $data['content']) && !empty(trim($data['content']))) {
        $commentId = intval($data['id']);
        $content = trim($data['content']);

        // 驗證用戶是否登入
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];

            // 確認用戶是否擁有修改權限
            $checkQuery = "SELECT id FROM comments WHERE id = ? AND user_id = ?";
            $stmt = $conn->prepare($checkQuery);

            if ($stmt === false) {
                echo json_encode(["success" => false, "error" => "SQL 準備失敗"]);
                exit();
            }

            $stmt->bind_param("ii", $commentId, $userId);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // 執行更新操作
                $updateQuery = "UPDATE comments SET content = ?, updated_at = NOW() WHERE id = ?";
                $updateStmt = $conn->prepare($updateQuery);

                if ($updateStmt === false) {
                    echo json_encode(["success" => false, "error" => "SQL 準備失敗"]);
                    exit();
                }

                $updateStmt->bind_param("si", $content, $commentId);

                if ($updateStmt->execute()) {
                    echo json_encode(["success" => true]);
                } else {
                    echo json_encode(["success" => false, "error" => "留言更新失敗"]);
                }
            } else {
                echo json_encode(["success" => false, "error" => "無權修改該留言"]);
            }
        } else {
            echo json_encode(["success" => false, "error" => "用戶未登入"]);
        }
    } else {
        echo json_encode(["success" => false, "error" => "請求資料無效"]);
    }
} else {
    echo json_encode(["success" => false, "error" => "無效的請求方法"]);
}

// 關閉資料庫連線
CloseCon($conn);
?>
